class SQLError(Exception):
    pass
